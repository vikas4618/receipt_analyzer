from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
import os
import shutil
import sqlite3
from PIL import Image
import pytesseract

# NEW: Import analysis logic
from algorithms import compute_aggregates, monthly_spend_trend

app = FastAPI()

# Allow frontend (localhost:3000 or 8501) to access backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict this to allowed domains
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Optional: path to tesseract binary
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# --------------------- DATABASE FUNCTIONS ---------------------

def init_db():
    conn = sqlite3.connect("receipts.db")
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS receipts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT,
            path TEXT,
            extracted_text TEXT
        )
    ''')
    conn.commit()
    conn.close()

def store_data(filename, path, extracted_text):
    conn = sqlite3.connect("receipts.db")
    c = conn.cursor()
    c.execute(
        "INSERT INTO receipts (filename, path, extracted_text) VALUES (?, ?, ?)",
        (filename, path, extracted_text)
    )
    conn.commit()
    conn.close()

def get_all_data():
    conn = sqlite3.connect("receipts.db")
    c = conn.cursor()
    c.execute("SELECT filename, path, extracted_text FROM receipts ORDER BY id DESC")
    rows = c.fetchall()
    conn.close()
    return [{"filename": r[0], "path": r[1], "extracted_text": r[2]} for r in rows]

# --------------------- API ROUTES ---------------------

@app.on_event("startup")
def startup_event():
    init_db()

@app.post("/upload/")
async def upload(file: UploadFile = File(...)):
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    extracted_text = ""
    try:
        if file.filename.lower().endswith((".png", ".jpg", ".jpeg")):
            image = Image.open(file_path)
            extracted_text = pytesseract.image_to_string(image)
    except Exception as e:
        extracted_text = f"Error during OCR: {str(e)}"

    # Store in DB
    store_data(file.filename, file_path, extracted_text)

    return {
        "filename": file.filename,
        "message": "File uploaded and saved successfully",
        "path": file_path,
        "extracted_text": extracted_text
    }

@app.get("/history/")
def history():
    return get_all_data()

# --------------------- NEW ANALYSIS ENDPOINT ---------------------

@app.get("/analyze/")
def analyze():
    # You can replace this mock data with parsed & cleaned DB content later
    data = [
        {"date": "2025-06-01", "vendor": "Flipkart", "amount": 1200},
        {"date": "2025-06-02", "vendor": "Amazon", "amount": 750},
        {"date": "2025-06-03", "vendor": "Flipkart", "amount": 2200},
        {"date": "2025-06-04", "vendor": "Zomato", "amount": 430}
    ]

    result = {
        "aggregates": compute_aggregates(data),
        "monthly_trend": monthly_spend_trend(data),
        "data": data
    }
    return result

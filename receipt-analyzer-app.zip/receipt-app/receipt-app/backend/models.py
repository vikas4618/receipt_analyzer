from sqlalchemy import Column, Integer, String, Float, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

engine = create_engine("sqlite:///receipts.db", connect_args={"check_same_thread":False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

class Receipt(Base):
    __tablename__ = "receipts"
    id = Column(Integer, primary_key=True)
    vendor = Column(String)
    date = Column(String)
    amount = Column(Float)
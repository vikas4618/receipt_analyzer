from collections import Counter
from statistics import mean, median, mode
import pandas as pd

def search_by_vendor(data, keyword):
    return [entry for entry in data if keyword.lower() in entry["vendor"].lower()]

def search_by_amount_range(data, min_amt, max_amt):
    return [entry for entry in data if min_amt <= entry["amount"] <= max_amt]

def sort_data(data, by="amount", reverse=False):
    return sorted(data, key=lambda x: x[by], reverse=reverse)

def compute_aggregates(data):
    amounts = [d["amount"] for d in data]
    vendors = [d["vendor"] for d in data]
    return {
        "sum": sum(amounts),
        "mean": mean(amounts),
        "median": median(amounts),
        "mode": mode(amounts),
        "vendor_histogram": dict(Counter(vendors)),
    }

def monthly_spend_trend(data):
    df = pd.DataFrame(data)
    df["date"] = pd.to_datetime(df["date"])
    trend = df.groupby(df["date"].dt.to_period("M"))["amount"].sum()
    return trend.to_dict()

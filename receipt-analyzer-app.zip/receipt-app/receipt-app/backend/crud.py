import pytesseract, re
from models import SessionLocal, Receipt

def extract_and_store(path):
    text = pytesseract.image_to_string(path)
    vendor = text.split("\n")[0]
    date = re.search(r"\d{2}/\d{2}/\d{4}", text).group(0)
    amount = float(re.search(r"\d+\.\d{2}", text).group(0))

    db = SessionLocal()
    r = Receipt(vendor=vendor, date=date, amount=amount)
    db.add(r); db.commit(); db.refresh(r)
    db.close()
    return {"id": r.id, "vendor": vendor, "date": date, "amount": amount}
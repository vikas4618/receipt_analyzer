import streamlit as st
import requests
import pandas as pd
from collections import Counter
from datetime import datetime

API = "http://localhost:8000"

st.set_page_config(page_title="Receipt Analyzer", layout="wide")
st.title("🧾 Receipt Uploader & Analyzer")

# Upload and OCR Section
uploaded = st.file_uploader("Upload a receipt", type=["jpg", "png", "pdf", "txt", "jpeg"])

if uploaded:
    st.image(uploaded, caption="Uploaded File Preview", use_column_width=True)

    if st.button("Extract"):
        files = {"file": (uploaded.name, uploaded.getvalue(), uploaded.type)}
        try:
            res = requests.post(API + "/upload/", files=files)
            res.raise_for_status()
        except requests.exceptions.RequestException as e:
            st.error(f"❌ Error: {e}")
        else:
            data = res.json()
            st.success("✅ Extracted successfully!")

            st.write("**Filename:**", data.get("filename"))
            st.write("**Saved Path:**", data.get("path"))

            extracted_text = data.get("extracted_text", "").strip()
            if extracted_text:
                st.subheader("📄 Extracted Text")
                st.text_area("Text", extracted_text, height=300)
            else:
                st.warning("⚠️ No text could be extracted.")

st.markdown("---")

# Upload History Section
if st.button("📜 Load Upload History"):
    try:
        res = requests.get(API + "/history/")
        res.raise_for_status()
    except requests.exceptions.RequestException as e:
        st.error(f"❌ Error loading history: {e}")
    else:
        history = res.json()
        if history:
            df = pd.DataFrame(history)
            st.subheader("📁 Uploaded Receipts Data")

            # --- Search ---
            search_col, range_col, regex_col = st.columns(3)
            with search_col:
                keyword = st.text_input("🔍 Search Keyword in Text")
                if keyword:
                    df = df[df["extracted_text"].str.contains(keyword, case=False, na=False)]

            with range_col:
                min_len = st.number_input("📏 Min Text Length", min_value=0, value=0)
                max_len = st.number_input("📏 Max Text Length", min_value=0, value=10000)
                df = df[df["extracted_text"].str.len().between(min_len, max_len)]

            with regex_col:
                pattern = st.text_input("🧵 Regex Pattern")
                if pattern:
                    df = df[df["extracted_text"].str.contains(pattern, regex=True, na=False)]

            # --- Sorting ---
            sort_col = st.selectbox("↕️ Sort By", ["filename", "path", "extracted_text"], index=0)
            sort_order = st.radio("Order", ["Ascending", "Descending"])
            df = df.sort_values(by=sort_col, ascending=(sort_order == "Ascending"))

            st.dataframe(df[["filename", "path", "extracted_text"]])

            # --- Aggregation ---
            st.markdown("## 📊 Aggregation & Statistics")

            all_text = " ".join(df["extracted_text"].dropna().tolist())
            words = all_text.split()
            word_counts = Counter(words)

            st.write(f"🧮 **Total Receipts:** {len(df)}")
            st.write(f"🔢 **Total Words Extracted:** {len(words)}")
            st.write(f"🗂️ **Top 10 Frequent Words:**")
            st.write(dict(word_counts.most_common(10)))

            df["length"] = df["extracted_text"].str.len()
            st.write(f"📏 **Average Text Length:** {df['length'].mean():.2f}")
            st.write(f"📈 **Max Text Length:** {df['length'].max()}")
            st.write(f"📉 **Min Text Length:** {df['length'].min()}")
        else:
            st.info("No previous uploads found.")

